package com.kaiburr.restapp.services;

import com.kaiburr.restapp.model.Server;
import com.kaiburr.restapp.repositories.ServerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServerServices {

    @Autowired
    ServerRepository serverRepository;

    public List<Server> getAllServers(){
        return serverRepository.findAll();
    }

    public Server getById(String id){
        return serverRepository.findById(id).orElse(null);
    }

    public void add(Server server){
        serverRepository.save(server);
    }

    public void delete(String id){
        serverRepository.deleteById(id);
    }

    public List<Server> find(String name){
        return serverRepository.findByName(name);
    }

}
