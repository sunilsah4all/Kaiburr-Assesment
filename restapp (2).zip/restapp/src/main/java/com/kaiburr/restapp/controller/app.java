package com.kaiburr.restapp.controller;

import com.kaiburr.restapp.model.Server;
import com.kaiburr.restapp.services.ServerServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/servers")
public class app {

    @Autowired
    ServerServices services;

    @GetMapping
    public List<Server> getServers(){
        return services.getAllServers();
    }

    @GetMapping("/id/{id}")
    public Server getServerById(@PathVariable String id){
        return services.getById(id);
    }

    @GetMapping("/name/{name}")
    public List<Server> getServersByName(@PathVariable String name){
        return services.find(name);
    }

    @PostMapping
    public void addServer(@RequestBody Server server){
        services.add(server);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteServer(@PathVariable String id){
        services.delete(id);
    }

}
