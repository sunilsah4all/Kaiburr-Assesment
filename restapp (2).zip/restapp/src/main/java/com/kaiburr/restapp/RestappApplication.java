package com.kaiburr.restapp;

import com.kaiburr.restapp.model.Server;
import com.kaiburr.restapp.repositories.ServerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@SpringBootApplication
public class RestappApplication implements CommandLineRunner{


	@Autowired
	ServerRepository serverRepository;

	public static void main(String[] args) {
		SpringApplication.run(RestappApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		List<Server> serversList = new ArrayList<>(
				Arrays.asList(
						new Server("my centos", "123","java","django"),
						new Server("Hello world","234","python","django")
				)
		);

		if(serverRepository.findAll().isEmpty())serverRepository.insert(serversList);
	}
}
