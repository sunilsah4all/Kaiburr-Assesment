package com.kaiburr.restapp.repositories;

import com.kaiburr.restapp.model.Server;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;

public class Servers {
    public static List<Server> serversList = new ArrayList<>(
            Arrays.asList(
                    new Server("my centos", "123","java","django"),
                    new Server("Hello world","234","python","django")
            )
    );
}
